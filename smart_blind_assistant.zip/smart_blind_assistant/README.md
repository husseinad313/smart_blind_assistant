# 👁️ Smart Vision Assistant for the Visually Impaired

A real-time object detection system powered by **YOLOv8 + Flask + Text-to-Speech**, designed to help blind and visually impaired users navigate safely.

---

## 🚀 Features

| Feature | Description |
|--------|-------------|
| 🎯 Real-time Detection | YOLOv8 detects 80+ object classes at 20+ FPS |
| 🔊 Voice Alerts | `pyttsx3` speaks danger warnings with direction & distance |
| 🔴 Danger Classification | HIGH / MEDIUM / LOW danger levels with color-coded UI |
| 📡 Live WebSocket Feed | Socket.IO pushes detections to the browser instantly |
| 🎵 Audio Beeps | Web Audio API plays beep patterns by danger severity |
| 🧭 Direction Awareness | LEFT / CENTER / RIGHT zones for spatial guidance |
| 📏 Distance Estimation | Very close / Close / Moderate / Far estimates |
| 🎙 Voice Input | Browser mic → speech-to-text → TTS speak-back |
| 🚨 Emergency Button | One-tap distress signal with alarm sounds |
| 📋 Detection Log | Timestamped history of all detections |

---

## 📦 Installation

### 1. Clone / download the project
```bash
git clone <your-repo>
cd smart_blind_assistant
```

### 2. Create a virtual environment
```bash
python -m venv venv
source venv/bin/activate        # Linux/macOS
venv\Scripts\activate           # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

> YOLOv8 (`ultralytics`) will **automatically download** the `yolov8n.pt` weights (~6 MB) on first run.

### 4. (Linux only) Install TTS system dependency
```bash
sudo apt-get install espeak
```

---

## ▶️ Run

```bash
python app.py
```

Open your browser: **http://localhost:5000**

Make sure your **webcam** is connected and accessible.

---

## 🏗 Project Structure

```
smart_blind_assistant/
│
├── app.py               # Flask app, YOLO detection, TTS engine
├── requirements.txt     # Python dependencies
├── README.md
│
└── templates/
    └── index.html       # Full-stack UI (Socket.IO, Web Audio, Speech API)
```

---

## 🔊 Voice Alert Logic

| Danger Level | Objects | Cooldown | Beep |
|---|---|---|---|
| 🔴 HIGH | car, truck, bus, knife, scissors | 4s | 3× descending sawtooth |
| 🟡 MEDIUM | bicycle, dog, traffic light | 4s | 2× triangle beep |
| 🟢 LOW | chair, person, bottle, etc. | 8s (grouped) | Silent |

Voice message example:
> *"Danger! Car on your left, very close"*
> *"Caution! Bicycle to the center, moderate distance"*

---

## 🧩 Add More Danger Objects

In `app.py`, extend the `DANGER_OBJECTS` dictionary:

```python
DANGER_OBJECTS = {
    'car': ('HIGH', 'Warning! Car detected!'),
    # Add your custom objects:
    'skateboard': ('MEDIUM', 'Caution! Skateboard nearby'),
    'ladder': ('HIGH', 'Warning! Ladder in the way!'),
    ...
}
```

---

## ⚙️ Configuration

| Variable | Default | Description |
|---|---|---|
| `SPEAK_COOLDOWN` | `4.0s` | Minimum time between same-object alerts |
| `conf=0.45` | 45% | YOLO confidence threshold |
| `CAP_PROP_FPS` | 20 | Camera frame rate |
| TTS rate | 165 wpm | Speech speed (`engine.setProperty('rate', ...)`) |

---

## 🌐 Browser Requirements

- Chrome / Edge recommended (for Web Speech API mic input)
- Firefox works for detection; mic input may need enabling

---

## 📌 Tips

- Use a **wide-angle USB camera** for better field of view
- Run on a **Raspberry Pi 5** or laptop for portable use
- Attach **earphones** so alerts don't disturb others
- `yolov8s.pt` (small) gives better accuracy if GPU is available

---

## 🛡 License

MIT — Free to use, modify, and distribute.
