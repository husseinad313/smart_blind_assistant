import cv2
import numpy as np
import base64
import json
import time
import threading
import pyttsx3
from flask import Flask, render_template, Response, jsonify, request
from flask_socketio import SocketIO, emit
from ultralytics import YOLO
import queue
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'smart_blind_assistant_2024'
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# ─── YOLO Model ───────────────────────────────────────────────────────────────
model = YOLO('yolov8n.pt')  # auto-downloads on first run

# ─── TTS Engine (thread-safe queue) ──────────────────────────────────────────
tts_queue = queue.Queue()
tts_lock = threading.Lock()

def tts_worker():
    engine = pyttsx3.init()
    engine.setProperty('rate', 165)
    engine.setProperty('volume', 1.0)
    # pick a clear voice
    voices = engine.getProperty('voices')
    for v in voices:
        if 'english' in v.name.lower() or 'en' in v.id.lower():
            engine.setProperty('voice', v.id)
            break
    while True:
        text = tts_queue.get()
        if text is None:
            break
        engine.say(text)
        engine.runAndWait()

tts_thread = threading.Thread(target=tts_worker, daemon=True)
tts_thread.start()

def speak(text, priority=False):
    if priority:
        with tts_lock:
            while not tts_queue.empty():
                try: tts_queue.get_nowait()
                except: pass
    tts_queue.put(text)

# ─── Danger & Context Mapping ─────────────────────────────────────────────────
DANGER_OBJECTS = {
    'car': ('HIGH', 'Warning! Car detected!'),
    'truck': ('HIGH', 'Warning! Truck ahead!'),
    'bus': ('HIGH', 'Warning! Bus detected!'),
    'motorcycle': ('HIGH', 'Warning! Motorcycle nearby!'),
    'bicycle': ('MEDIUM', 'Caution! Bicycle ahead'),
    'traffic light': ('MEDIUM', 'Traffic light ahead'),
    'stop sign': ('MEDIUM', 'Stop sign detected'),
    'fire hydrant': ('LOW', 'Fire hydrant on the path'),
    'bench': ('LOW', 'Bench ahead'),
    'chair': ('LOW', 'Chair in the way'),
    'dining table': ('LOW', 'Table ahead'),
    'person': ('LOW', 'Person nearby'),
    'dog': ('MEDIUM', 'Dog detected nearby'),
    'cat': ('LOW', 'Cat nearby'),
    'bottle': ('LOW', 'Bottle on the ground'),
    'backpack': ('LOW', 'Backpack ahead'),
    'suitcase': ('LOW', 'Luggage ahead'),
    'umbrella': ('LOW', 'Umbrella nearby'),
    'handbag': ('LOW', 'Handbag nearby'),
    'knife': ('HIGH', 'Warning! Sharp object detected!'),
    'scissors': ('HIGH', 'Warning! Scissors detected!'),
}

DIRECTION_ZONES = {
    'left': (0, 0.33),
    'center': (0.33, 0.66),
    'right': (0.66, 1.0),
}

def get_direction(cx_ratio):
    for direction, (lo, hi) in DIRECTION_ZONES.items():
        if lo <= cx_ratio < hi:
            return direction
    return 'center'

def get_distance_estimate(box_height_ratio):
    if box_height_ratio > 0.5: return 'very close'
    if box_height_ratio > 0.3: return 'close'
    if box_height_ratio > 0.15: return 'moderate distance'
    return 'far away'

# ─── Detection State ──────────────────────────────────────────────────────────
last_spoken = {}      # label -> timestamp
SPEAK_COOLDOWN = 4.0  # seconds per object class
frame_count = 0
detection_stats = {'total': 0, 'high': 0, 'medium': 0, 'low': 0}

def process_frame(frame):
    global frame_count, detection_stats
    frame_count += 1
    h, w = frame.shape[:2]

    results = model(frame, conf=0.45, verbose=False)[0]
    detections = []
    high_danger = []
    medium_danger = []
    low_danger = []

    for box in results.boxes:
        cls_id = int(box.cls[0])
        label = model.names[cls_id]
        conf = float(box.conf[0])
        x1, y1, x2, y2 = map(int, box.xyxy[0])

        cx = (x1 + x2) / 2
        cy = (y1 + y2) / 2
        box_h_ratio = (y2 - y1) / h
        direction = get_direction(cx / w)
        distance = get_distance_estimate(box_h_ratio)

        danger_info = DANGER_OBJECTS.get(label, ('INFO', f'{label} detected'))
        danger_level = danger_info[0]

        detections.append({
            'label': label,
            'conf': round(conf, 2),
            'danger': danger_level,
            'direction': direction,
            'distance': distance,
            'box': [x1, y1, x2, y2],
            'cx': cx, 'cy': cy
        })

        if danger_level == 'HIGH': high_danger.append((label, direction, distance))
        elif danger_level == 'MEDIUM': medium_danger.append((label, direction, distance))
        elif danger_level == 'LOW': low_danger.append((label, direction, distance))

        # Draw on frame
        color = {'HIGH': (0,0,255), 'MEDIUM': (0,165,255), 'LOW': (0,255,0), 'INFO': (255,255,0)}.get(danger_level, (200,200,200))
        cv2.rectangle(frame, (x1,y1), (x2,y2), color, 2)
        cv2.circle(frame, (int(cx), int(cy)), 4, color, -1)
        text = f"{label} {conf:.0%} | {direction} | {distance}"
        cv2.putText(frame, text, (x1, y1-8), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)

    # Update stats
    detection_stats['total'] = len(detections)
    detection_stats['high'] = len(high_danger)
    detection_stats['medium'] = len(medium_danger)
    detection_stats['low'] = len(low_danger)

    # Speak alerts (cooldown per label)
    now = time.time()
    spoken_this_frame = set()

    for label, direction, distance in high_danger:
        key = f"{label}"
        if key not in spoken_this_frame and (now - last_spoken.get(key, 0)) > SPEAK_COOLDOWN:
            msg = f"Danger! {label} on your {direction}, {distance}"
            speak(msg, priority=True)
            last_spoken[key] = now
            spoken_this_frame.add(key)

    for label, direction, distance in medium_danger:
        key = f"{label}"
        if key not in spoken_this_frame and (now - last_spoken.get(key, 0)) > SPEAK_COOLDOWN:
            msg = f"Caution! {label} to the {direction}, {distance}"
            speak(msg)
            last_spoken[key] = now
            spoken_this_frame.add(key)

    # Group low-danger to avoid chatter
    if frame_count % 30 == 0 and low_danger:
        key = "low_group"
        if (now - last_spoken.get(key, 0)) > 8.0:
            items = list(set([l for l,_,_ in low_danger]))[:3]
            msg = "Nearby objects: " + ", ".join(items)
            speak(msg)
            last_spoken[key] = now

    return frame, detections

# ─── Camera Stream ────────────────────────────────────────────────────────────
camera = None
camera_lock = threading.Lock()
stream_active = False

def get_camera():
    global camera
    with camera_lock:
        if camera is None or not camera.isOpened():
            camera = cv2.VideoCapture(0)
            camera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            camera.set(cv2.CAP_PROP_FPS, 20)
    return camera

def generate_frames():
    global stream_active
    stream_active = True
    cap = get_camera()
    while stream_active:
        success, frame = cap.read()
        if not success:
            break
        frame, detections = process_frame(frame)
        socketio.emit('detections', {
            'detections': detections,
            'stats': detection_stats
        })
        ret, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
        frame_bytes = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
        time.sleep(0.04)

# ─── Routes ───────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/api/speak', methods=['POST'])
def api_speak():
    data = request.get_json()
    text = data.get('text', '')
    if text:
        speak(text, priority=True)
    return jsonify({'status': 'ok'})

@app.route('/api/stop', methods=['POST'])
def api_stop():
    global stream_active
    stream_active = False
    return jsonify({'status': 'stopped'})

@app.route('/api/stats')
def api_stats():
    return jsonify(detection_stats)

@socketio.on('connect')
def on_connect():
    speak("Smart Vision Assistant is ready. Point your camera to begin.", priority=True)
    emit('status', {'msg': 'Connected'})

@socketio.on('disconnect')
def on_disconnect():
    pass

if __name__ == '__main__':
    os.makedirs('templates', exist_ok=True)
    os.makedirs('static', exist_ok=True)
    speak("Starting Smart Vision Assistant for the visually impaired.")
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)
